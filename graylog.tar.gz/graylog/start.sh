#!/usr/bin/env bash


/usr/local/bin/docker-compose -f /home/graylog/docker-compose.yml up -d
